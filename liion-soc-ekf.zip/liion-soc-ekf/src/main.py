import csv
from pathlib import Path
import numpy as np
import matplotlib.pyplot as plt

from .experiment import run_experiment

RESULTS = Path(__file__).resolve().parents[1] / "results"
RESULTS.mkdir(exist_ok=True)


def main():
    data = run_experiment()

    reference = data["true_soc"]
    estimators = {
        "Coulomb Counting": data["cc_soc"],
        "Extended Kalman Filter": data["ekf_soc"],
    }

    metrics = {}
    for name, estimate in estimators.items():
        err = (estimate - reference) * 100.0
        metrics[name] = {
            "rmse": float(np.sqrt(np.mean(err**2))),
            "mae": float(np.mean(np.abs(err))),
            "max": float(np.max(np.abs(err))),
        }

    # SOC comparison
    fig, ax = plt.subplots(figsize=(10, 5))
    ax.plot(data["t"] / 60.0, reference * 100.0, label="True SOC")
    ax.plot(data["t"] / 60.0, data["cc_soc"] * 100.0, label="Coulomb Counting")
    ax.plot(data["t"] / 60.0, data["ekf_soc"] * 100.0, label="EKF")
    ax.set_xlabel("Time (min)")
    ax.set_ylabel("SOC (%)")
    ax.set_title("Battery SOC Estimation")
    ax.grid(True, alpha=0.25)
    ax.legend()
    fig.tight_layout()
    fig.savefig(RESULTS / "soc_comparison.png", dpi=180)
    plt.close(fig)

    # Voltage trace
    fig, ax = plt.subplots(figsize=(10, 5))
    ax.plot(data["t"] / 60.0, data["voltage_true"], label="True terminal voltage")
    ax.plot(data["t"] / 60.0, data["voltage_meas"], label="Measured voltage", alpha=0.55)
    ax.set_xlabel("Time (min)")
    ax.set_ylabel("Voltage (V)")
    ax.set_title("Battery Terminal Voltage")
    ax.grid(True, alpha=0.25)
    ax.legend()
    fig.tight_layout()
    fig.savefig(RESULTS / "voltage_fit.png", dpi=180)
    plt.close(fig)

    # Error
    fig, ax = plt.subplots(figsize=(10, 5))
    ax.plot(
        data["t"] / 60.0,
        (data["cc_soc"] - reference) * 100.0,
        label="Coulomb Counting error",
    )
    ax.plot(
        data["t"] / 60.0,
        (data["ekf_soc"] - reference) * 100.0,
        label="EKF error",
    )
    ax.axhline(0.0, linestyle="--", linewidth=1)
    ax.set_xlabel("Time (min)")
    ax.set_ylabel("SOC error (percentage points)")
    ax.set_title("SOC Estimation Error")
    ax.grid(True, alpha=0.25)
    ax.legend()
    fig.tight_layout()
    fig.savefig(RESULTS / "estimation_error.png", dpi=180)
    plt.close(fig)

    with open(RESULTS / "metrics.csv", "w", newline="", encoding="utf-8") as f:
        writer = csv.writer(f)
        writer.writerow(["Estimator", "RMSE (%)", "MAE (%)", "Max absolute error (%)"])
        for name in estimators:
            m = metrics[name]
            writer.writerow([name, f'{m["rmse"]:.4f}', f'{m["mae"]:.4f}', f'{m["max"]:.4f}'])

    print("Battery SOC estimation study complete.")
    for name, m in metrics.items():
        print(
            f'{name}: RMSE={m["rmse"]:.3f}% | '
            f'MAE={m["mae"]:.3f}% | Max={m["max"]:.3f}%'
        )


if __name__ == "__main__":
    main()
