import numpy as np
from dataclasses import dataclass


@dataclass
class BatteryParams:
    capacity_ah: float = 40.0
    eta_coulomb: float = 0.995
    r0_ohm: float = 0.075
    rp_ohm: float = 0.030
    cp_farad: float = 1800.0


class TheveninBattery:
    """First-order Thevenin battery model with SOC-dependent OCV."""

    def __init__(self, params=None):
        self.p = params or BatteryParams()
        self.capacity_c = self.p.capacity_ah * 3600.0

    @staticmethod
    def ocv(soc):
        """Representative pack OCV curve for 0 <= SOC <= 1."""
        s = np.clip(soc, 0.0, 1.0)
        return (
            43.0
            + 8.0 * s
            + 1.9 * np.tanh((s - 0.50) * 7.0)
            + 0.35 * np.tanh((s - 0.14) * 16.0)
            - 0.20 * np.tanh((s - 0.88) * 14.0)
        )

    @staticmethod
    def docv_dsoc(soc):
        s = np.clip(soc, 0.0, 1.0)
        z1 = 7.0 * (s - 0.50)
        z2 = 16.0 * (s - 0.14)
        z3 = 14.0 * (s - 0.88)
        return (
            8.0
            + 1.9 * 7.0 * (1.0 - np.tanh(z1) ** 2)
            + 0.35 * 16.0 * (1.0 - np.tanh(z2) ** 2)
            - 0.20 * 14.0 * (1.0 - np.tanh(z3) ** 2)
        )

    def voltage(self, soc, v_rc, current):
        """Terminal voltage. Positive current = discharge."""
        return self.ocv(soc) - current * self.p.r0_ohm - v_rc

    def step(self, soc, v_rc, current, dt):
        """Advance the hidden plant state by one timestep."""
        alpha = np.exp(-dt / (self.p.rp_ohm * self.p.cp_farad))
        soc_next = np.clip(
            soc - self.p.eta_coulomb * current * dt / self.capacity_c,
            0.0, 1.0
        )
        vrc_next = alpha * v_rc + self.p.rp_ohm * (1.0 - alpha) * current
        return float(soc_next), float(vrc_next)
