import numpy as np
from .battery_model import TheveninBattery
from .estimators import CoulombCounter, ExtendedKalmanFilter


def current_profile(t):
    """Synthetic EV-style signed current profile; positive = discharge."""
    base = 7.0 + 2.5 * np.sin(2 * np.pi * t / 480.0)
    accel = 12.0 * (np.sin(2 * np.pi * t / 130.0) > 0.72)
    regen = -8.0 * (np.sin(2 * np.pi * t / 85.0) < -0.80)
    rest = np.where((t % 360.0) < 35.0, -1.5, 0.0)
    return base + accel + regen + rest


def run_experiment(
    duration_s=7200.0,
    dt=1.0,
    seed=11,
    initial_true_soc=0.82,
    initial_est_soc=0.76,
):
    rng = np.random.default_rng(seed)
    battery = TheveninBattery()
    t = np.arange(0.0, duration_s + dt, dt)
    current_true = current_profile(t)

    true_soc = np.empty_like(t)
    true_vrc = np.empty_like(t)
    true_voltage = np.empty_like(t)
    true_soc[0] = initial_true_soc
    true_vrc[0] = 0.0

    for k in range(len(t) - 1):
        true_voltage[k] = battery.voltage(
            true_soc[k], true_vrc[k], current_true[k]
        )
        true_soc[k + 1], true_vrc[k + 1] = battery.step(
            true_soc[k], true_vrc[k], current_true[k], dt
        )

    true_voltage[-1] = battery.voltage(
        true_soc[-1], true_vrc[-1], current_true[-1]
    )

    # Sensor model.
    current_meas = (
        current_true
        + 0.035
        + rng.normal(0.0, 0.05, size=len(t))
    )
    voltage_meas = (
        true_voltage
        + rng.normal(0.0, 0.010, size=len(t))
    )

    cc = CoulombCounter(battery, initial_est_soc)
    ekf = ExtendedKalmanFilter(battery, initial_est_soc)

    cc_soc = np.empty_like(t)
    ekf_soc = np.empty_like(t)
    ekf_vrc = np.empty_like(t)
    innovation = np.empty_like(t)

    for k in range(len(t)):
        cc_soc[k] = cc.update(current_meas[k], dt)
        ekf_soc[k], ekf_vrc[k], innovation[k] = ekf.update(
            current_meas[k], voltage_meas[k], dt
        )

    return {
        "t": t,
        "current_true": current_true,
        "current_meas": current_meas,
        "voltage_true": true_voltage,
        "voltage_meas": voltage_meas,
        "true_soc": true_soc,
        "cc_soc": cc_soc,
        "ekf_soc": ekf_soc,
        "ekf_vrc": ekf_vrc,
        "innovation": innovation,
    }
