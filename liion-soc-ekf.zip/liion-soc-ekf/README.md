# Li-Ion Battery SOC Estimation — Coulomb Counting vs. Extended Kalman Filter

A reproducible Python project for estimating the state of charge (SOC) of a lithium-ion battery from current and terminal-voltage measurements.

## What this project demonstrates

- Battery equivalent-circuit modelling
- SOC-dependent open-circuit voltage (OCV)
- First-order RC polarization dynamics
- Discrete-time Coulomb counting
- Extended Kalman filtering
- Noisy voltage/current measurements
- Quantitative estimation metrics
- Automated unit tests
- Reproducible engineering plots

## Requirements

Python 3.10+

```bash
pip install -r requirements.txt
```

Run the complete study:

```bash
python -m src.main
```

Run tests:

```bash
python -m unittest discover -s tests -v
```

## Repository structure

```text
liion-soc-ekf/
├── README.md
├── requirements.txt
├── .gitignore
├── LICENSE
├── src/
│   ├── __init__.py
│   ├── battery_model.py
│   ├── estimators.py
│   ├── experiment.py
│   └── main.py
├── tests/
│   └── test_battery_soc.py
├── docs/
│   └── methodology.md
└── results/
    ├── soc_comparison.png
    ├── voltage_fit.png
    ├── estimation_error.png
    └── metrics.csv
```

## Battery model

The pack is represented by a first-order Thevenin equivalent-circuit model:

```text
       R0
  ───/\/\/───┬──── Vterm
             │
             ├── Rp ── Cp ──┐
             │              │
            OCV(SOC) ───────┘
```

The terminal-voltage relation is:

\[
V_t = OCV(SOC) - I R_0 - V_{RC}
\]

where positive current denotes discharge.

The RC polarization state is updated using:

\[
V_{RC,k+1}=aV_{RC,k}+R_p(1-a)I_k
\]

with

\[
a=e^{-\Delta t/(R_pC_p)}.
\]

SOC is propagated using:

\[
SOC_{k+1}=SOC_k-\frac{\eta I_k\Delta t}{Q}.
\]

## EKF formulation

The state vector is:

```text
x = [SOC, V_Rc]^T
```

The nonlinear measurement equation is:

\[
V_t = OCV(SOC)-IR_0-V_{RC}.
\]

The EKF linearizes the measurement around the current state using:

\[
H =
\begin{bmatrix}
dOCV/dSOC & -1
\end{bmatrix}.
\]

The filter combines current integration with terminal-voltage feedback to correct SOC drift.

## Experiment

A 2-hour synthetic EV-style signed-current profile is generated with:

- low-current cruising,
- acceleration pulses,
- regenerative-current pulses,
- rest periods.

The measurement layer adds Gaussian noise and a small constant current-sensor bias.

The reference is the hidden plant SOC; estimators only receive measured current and voltage.

## Metrics

The script reports:

- SOC RMSE
- SOC MAE
- Maximum absolute SOC error
- Terminal-voltage RMSE

Results are written to:

```text
results/metrics.csv
```

## Engineering interpretation

Coulomb counting is simple and computationally cheap, but its error accumulates because current is integrated over time. The EKF uses a battery model and measured terminal voltage to provide a correction path and reduce long-term drift under the simulated conditions.

This is a simulation study using representative battery parameters; it is not a characterization of a specific commercial cell.

## Author

Fatin Nihal Islam  
Electrical & Electronic Engineering, KUET

## License

MIT
