# Methodology

## 1. Battery parameterization

The simulation uses representative pack-level parameters rather than claiming a specific manufacturer cell:

- Nominal capacity: 40 Ah
- Nominal operating-voltage region: approximately 48 V
- Pack-level Thevenin resistance: 75 mΩ
- Polarization resistance: 30 mΩ
- Polarization capacitance: 1800 F

The OCV curve is a smooth analytical approximation with a mid-SOC plateau and steeper end regions.

## 2. Dynamic model

The hidden plant contains two states:

```text
SOC, V_Rc
```

Terminal voltage is computed from OCV, ohmic drop and polarization voltage.

## 3. Measurement model

The experiment intentionally introduces:

- 0.05 A current-sensor noise
- 10 mV voltage-sensor noise
- 35 mA current-sensor bias

The bias stresses pure current integration and gives the voltage-corrected EKF a meaningful estimation problem.

## 4. Estimators

### Coulomb Counting

The measured current is integrated directly with the same nominal capacity and charge-efficiency assumption used by the estimator.

### Extended Kalman Filter

Prediction:
- propagate SOC from measured current,
- propagate RC polarization voltage.

Correction:
- predict terminal voltage,
- form the voltage innovation,
- update the state with the Kalman gain.

A Joseph-form covariance update is used to preserve numerical symmetry and positive-semidefinite behavior.

## 5. Evaluation

The hidden simulated plant SOC is used as the reference. The estimators only use measured current and measured terminal voltage.

The generated metrics make the comparison reproducible and auditable.
