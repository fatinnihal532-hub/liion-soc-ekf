import unittest
import sys
from pathlib import Path
import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from src.battery_model import TheveninBattery
from src.experiment import run_experiment


class TestBatteryModel(unittest.TestCase):
    def test_ocv_increases_with_soc(self):
        b = TheveninBattery()
        soc = np.linspace(0.0, 1.0, 400)
        ocv = np.array([b.ocv(s) for s in soc])
        self.assertGreaterEqual(float(np.min(np.diff(ocv))), -1e-8)

    def test_voltage_drops_with_positive_current(self):
        b = TheveninBattery()
        v_open = b.voltage(0.7, 0.0, 0.0)
        v_load = b.voltage(0.7, 0.0, 10.0)
        self.assertLess(v_load, v_open)

    def test_soc_bounds(self):
        b = TheveninBattery()
        soc, vrc = 0.05, 0.0
        for _ in range(10000):
            soc, vrc = b.step(soc, vrc, 100.0, 1.0)
        self.assertGreaterEqual(soc, 0.0)
        self.assertLessEqual(soc, 1.0)

    def test_reproducibility(self):
        a = run_experiment(duration_s=300.0, seed=11)
        b = run_experiment(duration_s=300.0, seed=11)
        np.testing.assert_allclose(a["ekf_soc"], b["ekf_soc"])

    def test_ekf_reduces_rmse(self):
        d = run_experiment(duration_s=1800.0, seed=11)
        cc_rmse = np.sqrt(np.mean((d["cc_soc"] - d["true_soc"]) ** 2))
        ekf_rmse = np.sqrt(np.mean((d["ekf_soc"] - d["true_soc"]) ** 2))
        self.assertLess(ekf_rmse, cc_rmse)


if __name__ == "__main__":
    unittest.main()
